public class Question2 {

    public static void main(String[] args) {

        int a[] = {7, 10, 18, 27, 36, 45, 54, 63, 72, 81, 90};
        System.out.println(sumUpTo(10)); // 55
        System.out.println( sumIntArrayAll(a) ); // 503
        System.out.println( sumIntArrayTwenty(a)); // 468
        System.out.println( countEvenNumbers(a)); // 6
        // Write code here to execute the functions yourself

    }
    static int sumUpTo( int n){
        return 0;
    }

    static int sumIntArrayAll( int[] array){
        return 0;
    }

    static int sumIntArrayTwenty( int[] array){
        return 0;
    }

    static int countEvenNumbers(int[] array){
        return 0;
    }
}