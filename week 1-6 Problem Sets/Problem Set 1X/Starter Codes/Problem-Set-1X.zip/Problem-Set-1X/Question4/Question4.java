public class Question4 {

    public static void main(String[] args) {

        System.out.println( binaryToDecimal("1011")); // 1011
        //execute your function with your own test cases

    }

    static int binaryToDecimal( String s){
        return 0;
    }
}
