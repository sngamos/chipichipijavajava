public class Question1 {

    public static void main(String[] args) {

        System.out.println(addTime(6, 30, 4, 45));
        //write code to execute the other testcases
    }

    static String addTime(int hour1, int min1, int hour2, int min2){
        return "";
    }
}
