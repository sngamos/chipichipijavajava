public class Question3 {

    public static void main(String[] args) {

        System.out.println( termsRequired(0.9)); // 6
        // Execute the function with your own test cases

    }

    static int termsRequired(double p){

        return 0;
    }
}
