// **ATTENTION**
// Edit just this file to submit your answer
// You need not edit TestTriangle.java
// 
// GeometricObject.class: 
// -- This is a Java bytecode file
// -- just leave it alone, you should not click on it and type in it 
// -- Reset the assignment (Actions --> Reset Assignment) if you encounter issues after clicking this file

class Triangle extends GeometricObject {


}
