public class MyRectangle2D {


}
