// **ATTENTION**
// Edit just this file to submit your answer
// You need not edit TestLinearEquation.java  

class LinearEquation {

}
