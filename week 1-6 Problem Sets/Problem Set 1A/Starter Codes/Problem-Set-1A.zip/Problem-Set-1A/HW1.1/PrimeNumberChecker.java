public class PrimeNumberChecker{
	public static int isPrime(int num){


	}
}
