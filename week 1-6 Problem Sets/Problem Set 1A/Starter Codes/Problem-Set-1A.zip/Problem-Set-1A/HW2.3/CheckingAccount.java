// **ATTENTION**
// Edit just this file to submit your answer
// You need not edit the TestCheckingAccount.java file 
// Leave the Account.class file alone  
// If your class has problems accessing the Account.class, 
// go to Actions -> Reset Assignment. Make sure you have your code stored on your computer. 

public class CheckingAccount extends Account{

}
