// ATTENTION 
// just edit this file
// TestAccount.java contains the test cases provided in the problem set 
// Put in any import statements that you need 


public class Account {


}

// **HINT**
// The problem set says "assume all accounts have the same interest rate". 
// What does that tell you about the variable(s) and/or method(s) relating to the interest rate? 