// **ATTENTION**
// Edit just this file to submit your answer
// You need not edit the TestPset1.java file 

public class Pset1 {	
	public static boolean isAllCharacterUnique(String sIn) {
	  //todo: add your implementation		
	}
	public static boolean isPermutation(String sIn1, String sIn2) {
	  //todo: add your implementation				
	}
}
